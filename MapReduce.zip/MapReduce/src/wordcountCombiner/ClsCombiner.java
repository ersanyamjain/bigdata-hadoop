package wordcountCombiner;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ClsCombiner extends Reducer<Text, IntWritable, Text, IntWritable> 
{
	public void reduce(Text key, Iterable<IntWritable> values, Context context)
	{
		try
		{
			Integer sum = 0;

			for(IntWritable value : values)
			{
				sum += value.get();
			}

			context.write(key, new IntWritable(sum));
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
}
