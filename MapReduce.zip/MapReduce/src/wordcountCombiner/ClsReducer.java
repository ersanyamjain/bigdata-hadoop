package wordcountCombiner;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ClsReducer extends Reducer<Text, IntWritable, Text, LongWritable> 
{
	public void reduce(Text key, Iterable<IntWritable> values, Context context)
	{
		try
		{
			Long sum = 0L;

			for(IntWritable value : values)
			{
				sum += value.get();
			}
			
			context.write(key, new LongWritable(sum));
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
}
