package nasCP;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ClsReducer extends Reducer<Text, DTNameAgeScore, Text, DTNameAgeScore> 
{
	public void reduce(Text key, Iterable<DTNameAgeScore> values, Context context)
	{
		try
		{
			Integer max = Integer.MIN_VALUE;
			
			DTNameAgeScore out = new DTNameAgeScore();

			for(DTNameAgeScore value : values)
			{
				if(value.score.get() > max)
				{
					max = value.score.get();
					
					out.name.set(value.name);
					out.age.set(value.age.get());
					out.score.set(value.score.get());
				}
			}
			
			context.write(key, out);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
}