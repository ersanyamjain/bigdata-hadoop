package nasCP;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ClsMapper extends Mapper<Text, Text, Text, DTNameAgeScore> 
{
	public void map(Text key, Text value, Context context)
	{
		try
		{
			String[] values = value.toString().split(",");
			
			DTNameAgeScore out = new DTNameAgeScore();
			
			out.name.set(values[0]);
			out.age.set(Integer.parseInt(values[1]));
			out.score.set(Integer.parseInt(values[2]));
			
			
			context.write(key, out);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
}