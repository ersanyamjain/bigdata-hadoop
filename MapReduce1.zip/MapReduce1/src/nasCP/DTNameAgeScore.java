package nasCP;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

public class DTNameAgeScore implements Writable 
{

	Text name ;
	IntWritable age,score;
	
	public DTNameAgeScore() 
	{
		name = new Text();
		age = new IntWritable();
		score = new IntWritable();
	}
	
	@Override
	public void readFields(DataInput in) throws IOException 
	{
		name.readFields(in);
		age.readFields(in);
		score.readFields(in);
	}

	@Override
	public void write(DataOutput out) throws IOException 
	{
		name.write(out);
		age.write(out);
		score.write(out);
	}
	
	public String toString()
	{
		return name+","+age+","+score;
	}

}