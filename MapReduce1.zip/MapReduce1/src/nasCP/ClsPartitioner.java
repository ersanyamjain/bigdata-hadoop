package nasCP;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class ClsPartitioner extends Partitioner<Text, DTNameAgeScore> 
{
	@Override
	public int getPartition(Text key, DTNameAgeScore value, int numPartition) 
	{
		if(value.age.get() <= 25)
			return 3%numPartition;
		
		else if(value.age.get() > 25 && value.age.get() <= 35)
			return 2%numPartition;
		
		else
			return 1%numPartition;
	}

}