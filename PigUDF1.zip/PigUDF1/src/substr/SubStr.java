package substr;

import java.io.IOException;
import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class SubStr extends EvalFunc<String> 
{
	@Override
	public String exec(Tuple t) throws IOException 
	{
		String returnString = new String();
		
		if(t.get(0).toString().length() < 5)
			returnString = t.get(0).toString();

		else
			returnString = t.get(0).toString().substring(0, 5);
		
		return returnString;
		
	}
}







