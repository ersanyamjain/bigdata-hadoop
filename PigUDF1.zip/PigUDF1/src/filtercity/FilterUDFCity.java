package filtercity;

import java.io.IOException;

import org.apache.pig.FilterFunc;
import org.apache.pig.data.Tuple;

public class FilterUDFCity extends FilterFunc 
{
	@Override
	public Boolean exec(Tuple t) throws IOException 
	{
		if(t.get(0).toString().length() >= 5)
			return true;
		else
			return false;
	}

}
